# DXLiveEmotionTracker
A demo of UWP FaceTracker and Azure cognitive services. The app use the stream of a camera to track faces, draw a square on the detected faces and append to them the age, gender and emotions that were returned by Azure Cognitive Services. The stream is not saved and all the work is done on the main memory.

Feel free to fork the demo and chage it at your will.

Next steps for the demo is to implement proper exception handling, adaptive UI.

The demo serves as a show off for Azure Cognitive services in hands-off enviornment
